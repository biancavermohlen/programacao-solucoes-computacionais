package com.example;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SistemaEventos {

  
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/sistemaeventos_db";
    private static final String USER = "usuario1";
    private static final String PASSWORD = "@123";

    private List<Evento> eventos;
    private Usuario usuarioLogado;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public SistemaEventos() {
        this.eventos = new ArrayList<>();
        // Tenta carregar dados ao iniciar
        carregarDados();
    }
    
    // --- Conexão e Carregamento Inicial ---

    private Connection conectar() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
    }
    
    private void carregarDados() {
        try {
            // Tenta carregar o usuário de teste de ID 1
            this.usuarioLogado = carregarOuCriarUsuarioInicial();
            
            // Carrega os eventos e participações
            carregarEventosDoBanco();
            
            System.out.println("\n✅ Dados carregados com sucesso do MySQL.");
        } catch (SQLException e) {
            System.err.println("\n❌ ERRO FATAL DE CONEXÃO/SQL. Verifique o servidor e a ConnectionString.");
            e.printStackTrace();
            // Cria um usuário mock se o DB falhar
            this.usuarioLogado = new Usuario(1, "Usuario Mock (DB OFFLINE)", "erro@db.com", "1234");
        }
    }

    private Usuario carregarOuCriarUsuarioInicial() throws SQLException {
        try (Connection conn = conectar()) {
            // 1. Tenta carregar o usuário de ID 1
            String sqlSelect = "SELECT Id, Nome, Email, Senha FROM Usuarios WHERE Id = 1";
            PreparedStatement psSelect = conn.prepareStatement(sqlSelect);
            ResultSet rs = psSelect.executeQuery();

            if (rs.next()) {
                System.out.println("✅ Usuário '" + rs.getString("Nome") + "' (ID: 1) carregado.");
                return new Usuario(rs.getInt("Id"), rs.getString("Nome"), rs.getString("Email"), rs.getString("Senha"));
            }

            // 2. Se não existir, cria o usuário inicial
            String sqlInsert = "INSERT INTO Usuarios (Id, Nome, Email, Senha) VALUES (1, 'Usuario Principal', 'teste@sistema.com', '1234')";
            PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
            psInsert.executeUpdate();

            System.out.println("✅ Usuário Principal (ID: 1) criado no MySQL para testes.");
            return new Usuario(1, "Usuario Principal", "teste@sistema.com", "1234");
        }
    }
    
    private void carregarEventosDoBanco() throws SQLException {
        eventos.clear();
        
        try (Connection conn = conectar()) {
            // 1. Carregar Eventos
            String sqlEventos = "SELECT Id, Nome, Endereco, Categoria, Horario, Descricao FROM Eventos ORDER BY Horario";
            PreparedStatement psEventos = conn.prepareStatement(sqlEventos);
            ResultSet rsEventos = psEventos.executeQuery();

            while (rsEventos.next()) {
                int id = rsEventos.getInt("Id");
                String nome = rsEventos.getString("Nome");
                String endereco = rsEventos.getString("Endereco");
                String categoria = rsEventos.getString("Categoria");
                // Conversão de Timestamp (SQL) para LocalDateTime (Java)
                LocalDateTime horario = rsEventos.getTimestamp("Horario").toLocalDateTime(); 
                String descricao = rsEventos.getString("Descricao");

                eventos.add(new Evento(id, nome, endereco, categoria, horario, descricao));
            }

            // 2. Carregar Participações
            String sqlParticipacoes = "SELECT EventoId, UsuarioId FROM Participacoes";
            PreparedStatement psParticipacoes = conn.prepareStatement(sqlParticipacoes);
            ResultSet rsParticipacoes = psParticipacoes.executeQuery();

            while (rsParticipacoes.next()) {
                int eventoId = rsParticipacoes.getInt("EventoId");
                int usuarioId = rsParticipacoes.getInt("UsuarioId");

                eventos.stream()
                       .filter(e -> e.getId() == eventoId)
                       .findFirst()
                       .ifPresent(e -> e.getParticipantesIds().add(usuarioId));
            }
        }
    }
    
    // --- Funcionalidades CRUD ---

    public void cadastrarNovoUsuario(String nome, String email, String senha) {
        try (Connection conn = conectar()) {
            String sql = "INSERT INTO Usuarios (Nome, Email, Senha) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nome);
            ps.setString(2, email);
            ps.setString(3, senha);
            
            ps.executeUpdate();
            
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int novoId = rs.getInt(1);
                this.usuarioLogado = new Usuario(novoId, nome, email, senha);
                System.out.println("\n👤 Usuário '" + nome + "' cadastrado (ID: " + novoId + ") e logado com sucesso!");
            }
        } catch (SQLIntegrityConstraintViolationException ex) {
            System.out.println("\n❌ Erro: Este email já está cadastrado.");
        } catch (SQLException ex) {
            System.out.println("\n❌ Erro ao cadastrar novo usuário no MySQL: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void cadastrarEvento(String nome, String endereco, String categoria, LocalDateTime horario, String descricao) {
        try (Connection conn = conectar()) {
            String sql = "INSERT INTO Eventos (Nome, Endereco, Categoria, Horario, Descricao) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nome);
            ps.setString(2, endereco);
            ps.setString(3, categoria);
            // Conversão de LocalDateTime para Timestamp (SQL)
            ps.setTimestamp(4, Timestamp.valueOf(horario)); 
            ps.setString(5, descricao);

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int novoId = rs.getInt(1);
                
                // Atualiza a lista em memória
                Evento novoEvento = new Evento(novoId, nome, endereco, categoria, horario, descricao);
                eventos.add(novoEvento);
                
                System.out.println("\n✅ Evento '" + nome + "' cadastrado com sucesso no MySQL! (ID: " + novoId + ")");
            }
        } catch (SQLException ex) {
            System.out.println("\n❌ Erro ao cadastrar evento no MySQL: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public void consultarEventos() {
        try {
            // Recarrega os dados para garantir o estado mais recente
            carregarEventosDoBanco();
        } catch (SQLException e) {
            System.err.println("\n❌ Erro ao recarregar eventos: " + e.getMessage());
        }

        if (eventos.isEmpty()) {
            System.out.println("\nNenhum evento cadastrado.");
            return;
        }

        LocalDateTime agora = LocalDateTime.now();
        // Ordena por horário mais próximo
        eventos.sort(Comparator.comparing(Evento::getHorario));

        System.out.println("\n--- 📅 Lista de Eventos (Ordenados por Horário Mais Próximo) ---");

        for (Evento e : eventos) {
            String status;
            if (e.getHorario().isBefore(agora)) {
                status = "(Ocorreu)";
            } 
            // Ocorrendo agora: entre 10 minutos atrás e 2 horas no futuro
            else if (e.getHorario().isBefore(agora.plusHours(2)) && e.getHorario().isAfter(agora.minusMinutes(10))) {
                status = "🔴 (OCORRENDO AGORA)";
            } 
            else {
                status = "(Próximo)";
            }

            String participando = e.getParticipantesIds().contains(usuarioLogado.getId()) ? "SIM" : "NÃO";
            
            System.out.println("\n[ID: " + e.getId() + "] **" + e.getNome() + "** - " + e.getCategoria() + " " + status);
            System.out.println("   Endereço: " + e.getEndereco());
            System.out.println("   Horário: " + e.getHorario().format(formatter));
            System.out.println("   Descrição: " + e.getDescricao());
            System.out.println("   Participando: " + participando + " (Total: " + e.getParticipantesIds().size() + ")");
        }
        System.out.println("\n--- Fim da Lista ---");
    }

    public void participarEvento(int eventoId) {
        Evento evento = eventos.stream().filter(e -> e.getId() == eventoId).findFirst().orElse(null);

        if (evento == null) {
            System.out.println("\n❌ Evento com ID " + eventoId + " não encontrado.");
            return;
        }

        if (evento.getParticipantesIds().contains(usuarioLogado.getId())) {
            System.out.println("\n⚠️ Você já está participando do evento: " + evento.getNome() + ".");
            return;
        }
        
        try (Connection conn = conectar()) {
            // Insere na tabela Participacoes (CREATE)
            String sql = "INSERT INTO Participacoes (EventoId, UsuarioId) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, eventoId);
            ps.setInt(2, usuarioLogado.getId());

            ps.executeUpdate();

            // Atualiza a lista em memória
            evento.getParticipantesIds().add(usuarioLogado.getId());
            
            System.out.println("\n🎉 Presença confirmada no evento: **" + evento.getNome() + "** (via MySQL)!");
        } catch (SQLException ex) {
            System.out.println("\n❌ Erro ao confirmar presença no MySQL: " + ex.getMessage());
        }
    }

    public void visualizarEventosConfirmados() {
        // Garante que a lista está atualizada
        try { carregarEventosDoBanco(); } catch (SQLException ignored) {}
        
        List<Evento> confirmados = eventos.stream()
            .filter(e -> e.getParticipantesIds().contains(usuarioLogado.getId()))
            .sorted(Comparator.comparing(Evento::getHorario))
            .toList();

        if (confirmados.isEmpty()) {
            System.out.println("\nVocê (" + usuarioLogado.getNome() + ") não confirmou presença em nenhum evento.");
            return;
        }

        System.out.println("\n--- ✅ Seus Eventos Confirmados (" + usuarioLogado.getNome() + ") ---");
        LocalDateTime agora = LocalDateTime.now();
        
        for (Evento e : confirmados) {
            String status = (e.getHorario().isBefore(agora)) ? "(Ocorreu)" : "(Agendado)";
            System.out.println("\n[ID: " + e.getId() + "] **" + e.getNome() + "** - " + e.getHorario().format(formatter) + " " + status);
        }
        System.out.println("--- Fim da Lista ---");
    }

    public void cancelarParticipacao(int eventoId) {
        Evento evento = eventos.stream().filter(e -> e.getId() == eventoId).findFirst().orElse(null);
        
        if (evento == null || !evento.getParticipantesIds().contains(usuarioLogado.getId())) {
            System.out.println("\n⚠️ Evento " + (evento != null ? evento.getNome() : eventoId) + " não encontrado ou você não está participando.");
            return;
        }

        try (Connection conn = conectar()) {
            // Deleta da tabela Participacoes (DELETE)
            String sql = "DELETE FROM Participacoes WHERE EventoId = ? AND UsuarioId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, eventoId);
            ps.setInt(2, usuarioLogado.getId());

            int linhasAfetadas = ps.executeUpdate();

            if (linhasAfetadas > 0) {
                // Atualiza a lista em memória
                evento.getParticipantesIds().remove((Integer) usuarioLogado.getId()); 
                System.out.println("\n🚫 Participação cancelada no evento: **" + evento.getNome() + "** (via MySQL).");
            }
        } catch (SQLException ex) {
            System.out.println("\n❌ Erro ao cancelar participação no MySQL: " + ex.getMessage());
        }
    }
}