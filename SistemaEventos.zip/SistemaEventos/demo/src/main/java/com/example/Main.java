package com.example;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static SistemaEventos sistema = new SistemaEventos();
    private static Scanner scanner = new Scanner(System.in);
    private static final List<String> CATEGORIAS_VALIDAS = Arrays.asList("Música", "Esporte", "Cultura", "Negócios", "Saúde");
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public static void main(String[] args) {
        boolean rodando = true;
        
        System.out.println("\n### 🤝 Sistema de Eventos em Java (MySQL Integrado) ###");
        
        while (rodando) {
            System.out.println("\n--- MENU PRINCIPAL ---");
            System.out.println("1. Cadastrar Evento");
            System.out.println("2. Consultar Todos os Eventos (com Notificações)");
            System.out.println("3. Participar de um Evento");
            System.out.println("4. Visualizar Meus Eventos Confirmados");
            System.out.println("5. Cancelar Participação em Evento");
            System.out.println("6. Cadastrar NOVO Usuário (Troca o usuário logado)");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            String opcao = scanner.nextLine();
            System.out.println();

            switch (opcao) {
                case "1":
                    handleCadastrarEvento();
                    break;
                case "2":
                    sistema.consultarEventos();
                    break;
                case "3":
                    handleParticiparEvento();
                    break;
                case "4":
                    sistema.visualizarEventosConfirmados();
                    break;
                case "5":
                    handleCancelarParticipacao();
                    break;
                case "6":
                    handleCadastrarNovoUsuario();
                    break;
                case "0":
                    rodando = false;
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
        System.out.println("\nPrograma encerrado. Até mais!");
        scanner.close();
    }
    
    private static void handleCadastrarEvento() {
        System.out.print("Nome do Evento: ");
        String nome = scanner.nextLine();
        
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        
        String categoria = "";
        while(true) {
            System.out.println("Categorias disponíveis: " + String.join(", ", CATEGORIAS_VALIDAS));
            System.out.print("Categoria: ");
            categoria = scanner.nextLine();
            if (CATEGORIAS_VALIDAS.contains(categoria)) {
                break;
            }
            System.out.println("❌ Categoria inválida. Por favor, escolha uma da lista.");
        }
        
        LocalDateTime horario = null;
        while(horario == null) {
            System.out.print("Horário (Formato dd/MM/yyyy HH:mm, ex: 31/12/2025 20:00): ");
            try {
                horario = LocalDateTime.parse(scanner.nextLine(), FORMATTER);
            } catch (DateTimeParseException e) {
                System.out.println("❌ Formato de data e hora inválido.");
            }
        }
        
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();

        sistema.cadastrarEvento(nome, endereco, categoria, horario, descricao);
    }
    
    private static void handleParticiparEvento() {
        System.out.print("ID do evento que deseja participar: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            sistema.participarEvento(id);
        } catch (NumberFormatException e) {
            System.out.println("❌ ID inválido.");
        }
    }
    
    private static void handleCancelarParticipacao() {
        System.out.print("ID do evento cuja participação deseja cancelar: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            sistema.cancelarParticipacao(id);
        } catch (NumberFormatException e) {
            System.out.println("❌ ID inválido.");
        }
    }
    
    private static void handleCadastrarNovoUsuario() {
        System.out.print("Novo Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Novo Email: ");
        String email = scanner.nextLine();
        System.out.print("Nova Senha: ");
        String senha = scanner.nextLine();
        
        sistema.cadastrarNovoUsuario(nome, email, senha);
    }
}
