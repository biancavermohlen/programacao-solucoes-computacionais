package com.example;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Evento {
    private int id;
    private String nome;
    private String endereco;
    private String categoria;
    private LocalDateTime horario; // Usando LocalDateTime para controle de data/hora
    private String descricao;
    
    // Lista em memória dos IDs dos usuários que participarão
    private List<Integer> participantesIds;

    // Construtor
    public Evento(int id, String nome, String endereco, String categoria, LocalDateTime horario, String descricao) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.categoria = categoria;
        this.horario = horario;
        this.descricao = descricao;
        this.participantesIds = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getEndereco() { return endereco; }
    public String getCategoria() { return categoria; }
    public LocalDateTime getHorario() { return horario; }
    public String getDescricao() { return descricao; }
    public List<Integer> getParticipantesIds() { return participantesIds; }

    public void setId(int id) { this.id = id; }
}